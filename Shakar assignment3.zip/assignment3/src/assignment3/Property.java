
package assignment3;
public class Property {
    protected double area;
    protected int numRooms;
    protected String neighborhood;
    protected double price;

    public Property(double area, int numRooms, String neighborhood, double price) {
        this.area = area;
        this.numRooms = numRooms;
        this.neighborhood = neighborhood;
        this.price = price;
    }

    public void display() {
        System.out.println("Area: " + area + " m2");
        System.out.println("Number of Rooms: " + numRooms);
        System.out.println("Neighborhood: " + neighborhood);
        System.out.println("Price: $" + price);
    }
}
