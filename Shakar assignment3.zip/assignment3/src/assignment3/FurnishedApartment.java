
package assignment3;

class FurnishedApartment extends Apartment {
    int furnitureQuality;

    public FurnishedApartment(double area, int numRooms, String neighborhood, double price, int floorNumber, boolean hasParkingLot, int furnitureQuality) {
        super(area, numRooms, neighborhood, price, floorNumber, hasParkingLot);
        this.furnitureQuality = furnitureQuality;
    }

    @Override
    public void display() {
        super.display();
        System.out.println("Type: Furnished Apartment");
        System.out.println("Furniture Quality: " + furnitureQuality);
    }
}
