
package assignment3;

class Apartment extends Property {
    int floorNumber;
    boolean hasParkingLot;

    public Apartment(double area, int numRooms, String neighborhood, double price, int floorNumber, boolean hasParkingLot) {
        super(area, numRooms, neighborhood, price);
        this.floorNumber = floorNumber;
        this.hasParkingLot = hasParkingLot;
    }

    @Override
    public void display() {
        super.display();
        System.out.println("Type: Apartment");
        System.out.println("Floor Number: " + floorNumber);
        System.out.println("Has Parking Lot: " + (hasParkingLot ? "Yes" : "No"));
    }
}

