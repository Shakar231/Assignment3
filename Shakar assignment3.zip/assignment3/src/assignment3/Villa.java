/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package assignment3;
class Villa extends Property {
    boolean hasSwimmingPool;
    int numAdjacentStreets;

    public Villa(double area, int numRooms, String neighborhood, double price, boolean hasSwimmingPool, int numAdjacentStreets) {
        super(area, numRooms, neighborhood, price);
        this.hasSwimmingPool = hasSwimmingPool;
        this.numAdjacentStreets = numAdjacentStreets;
    }

    @Override
    public void display() {
        super.display();
        System.out.println("Type: Villa");
        System.out.println("Has Swimming Pool: " + (hasSwimmingPool ? "Yes" : "No"));
        System.out.println("Number of Adjacent Streets: " + numAdjacentStreets);
    }
}


    
