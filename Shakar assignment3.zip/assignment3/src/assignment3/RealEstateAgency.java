
package assignment3;

import java.util.ArrayList;

class RealEstateAgency {
    private ArrayList<Property> properties = new ArrayList<>();

    public void addProperty(Property property) {
        properties.add(property);
    }

    public void removeProperty(Property property) {
        properties.remove(property);
    }

    public void displayProperties() {
        for (Property property : properties) {
            property.display();
            System.out.println("---------------------------------");
        }
    }

    public ArrayList<Property> getProperties() {
        return properties;
    }
}