
package assignment3;

import java.util.Scanner;

public class Assignment3 {
    public static void main(String[] args) {
        RealEstateAgency agency = new RealEstateAgency();

        // Adding some initial properties
        Villa villa1 = new Villa(250, 4, "Kani ba", 500000, true, 2);
        Apartment apartment1 = new Apartment(120, 3, "Sarchnar", 300000, 5, true);
        FurnishedApartment furnishedApartment1 = new FurnishedApartment(100, 2, "Raparin", 250000, 2, true, 3);

        agency.addProperty(villa1);
        agency.addProperty(apartment1);
        agency.addProperty(furnishedApartment1);

        Scanner scanner = new Scanner(System.in);

        while (true) {
            // Display available properties (updated list)
            System.out.println("Available properties:");
            agency.displayProperties();

            // User choice to view property
            System.out.println("Choose a property to view details (1 for Villa, 2 for Apartment, 3 for Furnished Apartment): ");
            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline character

            if (choice == 1 && agency.getProperties().contains(villa1)) {
                villa1.display();
            } else if (choice == 2 && agency.getProperties().contains(apartment1)) {
                apartment1.display();
            } else if (choice == 3 && agency.getProperties().contains(furnishedApartment1)) {
                furnishedApartment1.display();
            } else {
                System.out.println("Invalid choice or property no longer available.");
                continue;
            }

            // Ask if property is sold
            System.out.println("Was this property sold? (yes/no): ");
            String sold = scanner.nextLine();

            if (sold.equalsIgnoreCase("yes")) {
                if (choice == 1 && agency.getProperties().contains(villa1)) {
                    agency.removeProperty(villa1);
                    System.out.println("Villa has been sold and removed from the listing.");
                } else if (choice == 2 && agency.getProperties().contains(apartment1)) {
                    agency.removeProperty(apartment1);
                    System.out.println("Apartment has been sold and removed from the listing.");
                } else if (choice == 3 && agency.getProperties().contains(furnishedApartment1)) {
                    agency.removeProperty(furnishedApartment1);
                    System.out.println("Furnished Apartment has been sold and removed from the listing.");
                    
                }
            }

            // Ask if user wants to continue
            System.out.println("Would you like to check another property? (yes/no): ");
            String continueChoice = scanner.nextLine();
            if (continueChoice.equalsIgnoreCase("no")) {
                System.out.println("Exiting the program.");
                break;
            }
        }

        scanner.close();
    }
}